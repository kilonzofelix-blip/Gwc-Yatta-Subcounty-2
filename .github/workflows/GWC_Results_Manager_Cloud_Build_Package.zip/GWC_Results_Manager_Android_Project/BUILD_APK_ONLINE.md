# Build the installable APK online

This project includes a GitHub Actions workflow that compiles the Android APK in the cloud. The APK is not included yet because it must be built by that workflow.

1. Sign in to GitHub and create a new repository named `GWC-Results-Manager`.
2. Upload the **contents** of this project folder to the repository (including the `.github/workflows/build-apk.yml` file), then commit the files to the `main` branch.
3. Open the repository's **Actions** tab and select **Build Governor Wavinya Cup APK**.
4. If it has not started automatically after the upload, choose **Run workflow**.
5. When the run finishes successfully, open that run and find **Artifacts**. Download `Governor-Wavinya-Cup-Results-Manager-APK`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap the APK on your Android phone to install it. Android may ask you to allow installation from that source.

The APK is a debug-signed installable build. Keep the repository and downloaded APK private if you do not want to share the app publicly.
