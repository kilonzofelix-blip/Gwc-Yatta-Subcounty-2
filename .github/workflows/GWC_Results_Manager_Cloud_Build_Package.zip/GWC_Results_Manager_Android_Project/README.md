# Governor Wavinya Cup Results Manager — Android Studio project

This is an Android WebView wrapper project for the offline-first GWC results manager. It bundles the web app as an app asset so the interface and fixture data are available without an internet connection. Browser local storage is enabled and the Android file chooser supports uploading club crest images.

## Build an APK
1. Install Android Studio on a computer and allow it to install Android SDK Platform 35 and a compatible Gradle version.
2. Open this extracted folder (`GWC_Results_Manager_Android_Project`) in Android Studio.
3. Wait for Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. Android may ask you to allow installing apps from that source.

## Offline and data
- The app's HTML, CSS, JavaScript and fixtures are bundled in the APK.
- Results and crest data are stored in WebView local storage on this device.
- Export backups regularly. Reinstalling/clearing app storage may erase records.
- The HTML backup-download flow is browser-oriented; test backup/restore on the target Android version before using it for official records.
- This is a starter Android project, not a precompiled APK. This environment does not include Android SDK/Gradle build tooling, so it cannot produce and verify the binary APK here.
- The official tournament logo has not been included because the exact original logo asset was not available in the working files; do not replace it with a generated logo.
